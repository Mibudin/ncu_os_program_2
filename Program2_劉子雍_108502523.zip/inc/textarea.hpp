#pragma once
#ifndef TEXTAREA_H
#define TEXTAREA_H


namespace gol
{
    class Testarea
    {

    };
}

#endif
