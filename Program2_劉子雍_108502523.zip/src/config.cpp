#include"config.hpp"


int gol::turnPeriod = TURN_PERIOD;
